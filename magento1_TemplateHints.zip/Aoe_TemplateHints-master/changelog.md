# Aoe_TemplateHints Changelog

## v0.4.0 [2013-05-03]

* Added PHPStorm Remote Call support
    1. Install the "Remote Call" plugin in PHPStorm.
    2. Enable Remote Call feature in System > Configuration > Developer > AOE Template Hints
    3. Hover a block while showing the template hints (append ?ath=1 to the url)
    4. Click on the class name or on the template file name will make PHPStorm jump to this file.

## v0.3.0 (and before...)

* http://www.fabrizio-branca.de/magento-advanced-template-hints-20.html
* http://www.fabrizio-branca.de/magento-advanced-template-hints.html (german)
